package sudoku;

/**
 * Created with IntelliJ IDEA.
 * User: jburnham
 * Date: 11/8/13
 * Time: 4:22 PM
 * To change this template use File | Settings | File Templates.
 */
public class SudokuSolver {

    private Board game;

    public SudokuSolver() {}

    public SudokuSolver(Board game) {
        this.game = game;
    }


    public Board getGame() {
        return game;
    }

    public void setGame(Board game) {
        this.game = game;
    }

    public void solveGame() {
        for (int val = 0; val < Board.DEFAULT_SIZE; val++) {

        }
    }

    public void solveGame(int row, int col, int value) {
        boolean inRow = game.doesRowContain(row, value);
        boolean inCol = game.doesColumnContain(col, value);
        int section = game.calcSectionFromRowColumn(row, col);
        boolean inSection = game.doesSectionContain(section, value);

        System.out.println(value + " in row " + row + ": " + inRow);
        System.out.println(value + " in col " + col + ": " + inCol);
        System.out.println(value + " in sec " + section + ": " + inSection);
    }
}
