package sudoku;

/**
 * Created with IntelliJ IDEA.
 * User: jburnham
 * Date: 11/8/13
 * Time: 11:23 AM
 * To change this template use File | Settings | File Templates.
 */
public class Sudoku {
    public Sudoku() {

    }


    public static void main(String args[]) {
        Board game = new Board();
        setEasyBoard(game);
        System.out.println(game);
        System.out.println("Board is complete: " + game.isBoardCompleted());
        System.out.println("Board is safe: " + game.isBoardSafe());


    }

    public static void setEasyBoard(Board game) {
        game.addInitial(0,5,8);
        game.addInitial(0,8,4);

        game.addInitial(1,1,5);
        game.addInitial(1,2,4);
        game.addInitial(1,4,1);
        game.addInitial(1,5,6);

        game.addInitial(2,3,5);
        game.addInitial(2,6,1);

        game.addInitial(3,0,1);
        game.addInitial(3,2,3);
        game.addInitial(3,3,8);
        game.addInitial(3,6,9);

        game.addInitial(4,0,6);
        game.addInitial(4,2,8);
        game.addInitial(4,6,4);
        game.addInitial(4,8,3);

        game.addInitial(5,2,2);
        game.addInitial(5,5,9);
        game.addInitial(5,6,5);
        game.addInitial(5,8,1);

        game.addInitial(6,2,7);
        game.addInitial(6,5,2);

        game.addInitial(7,3,7);
        game.addInitial(7,4,8);
        game.addInitial(7,6,2);
        game.addInitial(7,7,6);

        game.addInitial(8,0,2);
        game.addInitial(8,3,3);
    }
}
